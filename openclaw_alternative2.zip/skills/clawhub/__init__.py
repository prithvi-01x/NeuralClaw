# ClawHub Bridge Adapter — bridging OpenClaw SKILL.md into NeuralClaw
