/**
 * NeuralClaw Web UI — Application Logic
 *
 * Connects to the gateway WebSocket server and provides a rich chat interface.
 * All agent communication goes through the gateway protocol.
 */

class NeuralClawApp {
    constructor() {
        this.ws = null;
        this.sessionId = null;
        this.trustLevel = 'low';
        this.turnCount = 0;
        this.toolCount = 0;
        this.pendingRequests = new Map(); // id → { resolve, reject }
        this.isConnected = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;

        // DOM refs
        this.messagesEl = document.getElementById('messages');
        this.inputEl = document.getElementById('message-input');
        this.sendBtn = document.getElementById('send-btn');
        this.statusDot = document.getElementById('status-dot');
        this.statusText = document.getElementById('status-text');
        this.sessionIdEl = document.getElementById('session-id');
        this.statsEl = document.getElementById('stats-display');
        this.welcomeEl = document.getElementById('welcome-screen');

        this._bindEvents();
        this._autoConnect();
    }

    // ─── Event Binding ──────────────────────────────────────────────────

    _bindEvents() {
        // Enter to send, Shift+Enter for newline
        this.inputEl.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.send();
            }
        });

        // Auto-resize textarea
        this.inputEl.addEventListener('input', () => {
            this.inputEl.style.height = 'auto';
            this.inputEl.style.height = Math.min(this.inputEl.scrollHeight, 200) + 'px';
        });

        // Trust level selector
        document.querySelectorAll('.trust-btn').forEach(btn => {
            btn.addEventListener('click', () => this._setTrust(btn.dataset.level));
        });
    }

    // ─── WebSocket Connection ───────────────────────────────────────────

    _autoConnect() {
        // Determine gateway URL — same host, default port 9090
        const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = location.hostname || '127.0.0.1';
        const port = location.port || '9090';
        this.gatewayUrl = `${protocol}//${host}:${port}`;
        this.connect();
    }

    connect() {
        this._updateStatus('connecting');

        try {
            this.ws = new WebSocket(this.gatewayUrl);
        } catch (e) {
            this._updateStatus('disconnected');
            this.toast('Failed to connect to gateway', 'error');
            return;
        }

        this.ws.onopen = () => {
            this.isConnected = true;
            this.reconnectAttempts = 0;
            this._updateStatus('connected');
            this.toast('Connected to NeuralClaw gateway', 'success');
            this._createSession();
        };

        this.ws.onmessage = (event) => {
            try {
                const msg = JSON.parse(event.data);
                this._handleMessage(msg);
            } catch (e) {
                console.error('Invalid message:', e);
            }
        };

        this.ws.onclose = () => {
            this.isConnected = false;
            this._updateStatus('disconnected');

            if (this.reconnectAttempts < this.maxReconnectAttempts) {
                const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000);
                this.reconnectAttempts++;
                setTimeout(() => this.connect(), delay);
            }
        };

        this.ws.onerror = () => {
            this._updateStatus('disconnected');
        };
    }

    _updateStatus(state) {
        const dot = this.statusDot;
        const text = this.statusText;

        dot.className = 'status-dot';
        if (state === 'connected') {
            dot.classList.add('connected');
            text.textContent = 'Connected';
        } else if (state === 'connecting') {
            text.textContent = 'Connecting…';
        } else {
            text.textContent = 'Disconnected';
        }
    }

    // ─── Send / Receive ──────────────────────────────────────────────────

    _send(msg) {
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
            this.toast('Not connected to gateway', 'error');
            return null;
        }
        if (!msg.id) msg.id = this._genId();
        this.ws.send(JSON.stringify(msg));
        return msg.id;
    }

    _genId() {
        return Math.random().toString(36).substring(2, 10);
    }

    async _createSession() {
        const id = this._send({
            type: 'session.create',
            data: { user_id: 'webui', trust_level: this.trustLevel },
        });
    }

    // ─── Message Handler ───────────────────────────────────────────────

    _handleMessage(msg) {
        switch (msg.type) {
            case 'session.created':
                this.sessionId = msg.session_id;
                this.sessionIdEl.textContent = this.sessionId.substring(0, 12) + '…';
                break;

            case 'response':
                this._handleResponse(msg);
                break;

            case 'confirm_request':
                this._showConfirmation(msg);
                break;

            case 'session.updated':
                if (msg.data.trust_level) {
                    this.trustLevel = msg.data.trust_level;
                    this._updateTrustUI();
                }
                if (msg.data.granted) {
                    document.getElementById('caps-display').textContent =
                        msg.data.granted.length > 0 ? msg.data.granted.join(', ') : 'None granted';
                }
                break;

            case 'error':
                this._addMessage('system', `❌ ${msg.data.message || 'Unknown error'}`);
                break;

            case 'pong':
                break;

            default:
                console.log('Unknown message type:', msg.type, msg);
        }
    }

    _handleResponse(msg) {
        const data = msg.data || {};
        const kind = data.kind || 'text';
        const text = data.text || '';
        const isFinal = data.is_final !== false;

        // Remove thinking indicator if present
        if (isFinal) {
            this._removeThinking();
        }

        switch (kind) {
            case 'text':
                if (isFinal && text) {
                    this._addMessage('assistant', text);
                    this.turnCount++;
                    this._updateStats();
                }
                break;

            case 'progress':
                this._updateProgress(text);
                break;

            case 'tool_result':
                this._addToolResult(text);
                this.toolCount++;
                this._updateStats();
                break;

            case 'plan':
                this._addMessage('assistant', text);
                break;

            case 'status':
                this._showStatusData(data);
                break;

            case 'error':
                this._addMessage('system', `❌ ${text}`);
                break;
        }
    }

    // ─── User Actions ──────────────────────────────────────────────────

    send() {
        const raw = this.inputEl.value.trim();
        if (!raw) return;

        this.inputEl.value = '';
        this.inputEl.style.height = 'auto';
        this._hideWelcome();

        // Handle slash commands
        if (raw.startsWith('/run ')) {
            const goal = raw.substring(5).trim();
            this._addMessage('user', raw);
            this._showThinking();
            this._send({
                type: 'run',
                session_id: this.sessionId,
                data: { goal },
            });
            return;
        }

        if (raw === '/skills' || raw === '/tools') {
            this.listSkills();
            return;
        }

        if (raw === '/status') {
            this.showStatus();
            return;
        }

        if (raw.startsWith('/trust ')) {
            const level = raw.substring(7).trim();
            this._setTrust(level);
            return;
        }

        if (raw === '/cancel') {
            this._send({ type: 'cancel', session_id: this.sessionId });
            this._addMessage('system', '🛑 Cancel signal sent.');
            return;
        }

        // Regular message
        this._addMessage('user', raw);
        this._showThinking();

        this._send({
            type: 'ask',
            session_id: this.sessionId,
            data: { message: raw },
        });
    }

    sendQuick(message) {
        this.inputEl.value = message;
        this.send();
    }

    runQuick(goal) {
        this.inputEl.value = `/run ${goal}`;
        this.send();
    }

    // ─── Chat Messages ────────────────────────────────────────────────

    _addMessage(role, text) {
        this._hideWelcome();

        const div = document.createElement('div');
        div.className = `message ${role}`;

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';

        if (role === 'assistant') {
            // Render markdown
            try {
                bubble.innerHTML = marked.parse(text, { breaks: true });
            } catch {
                bubble.textContent = text;
            }
        } else if (role === 'user') {
            bubble.textContent = text;
        } else {
            bubble.innerHTML = text;
        }

        div.appendChild(bubble);
        this.messagesEl.appendChild(div);
        this._scrollToBottom();
    }

    _addToolResult(text) {
        const div = document.createElement('div');
        div.className = 'message assistant';

        const tool = document.createElement('div');
        tool.className = 'tool-call';
        tool.innerHTML = text
            .replace(/✅/, '<span style="color: var(--success)">✅</span>')
            .replace(/❌/, '<span style="color: var(--danger)">❌</span>');

        div.appendChild(tool);
        this.messagesEl.appendChild(div);
        this._scrollToBottom();
    }

    _showThinking() {
        this._removeThinking();

        const div = document.createElement('div');
        div.className = 'thinking';
        div.id = 'thinking-indicator';
        div.innerHTML = `
      <div class="thinking-dots">
        <span></span><span></span><span></span>
      </div>
      <span class="thinking-text">Thinking…</span>
    `;
        this.messagesEl.appendChild(div);
        this._scrollToBottom();
    }

    _removeThinking() {
        const el = document.getElementById('thinking-indicator');
        if (el) el.remove();
    }

    _updateProgress(text) {
        // Update or create progress indicator
        let el = document.getElementById('progress-indicator');
        if (!el) {
            el = document.createElement('div');
            el.className = 'message assistant';
            el.id = 'progress-indicator';

            const bubble = document.createElement('div');
            bubble.className = 'message-bubble';
            bubble.style.color = 'var(--text-secondary)';
            bubble.style.fontSize = '13px';
            el.appendChild(bubble);

            this.messagesEl.appendChild(el);
        }
        el.querySelector('.message-bubble').textContent = text;
        this._scrollToBottom();
    }

    // ─── Confirmation Dialog ──────────────────────────────────────────

    _showConfirmation(msg) {
        this._removeThinking();
        const data = msg.data || {};

        const div = document.createElement('div');
        div.className = 'confirmation';
        div.id = `confirm-${data.tool_call_id}`;

        const riskIcon = data.risk_level === 'CRITICAL' ? '🚨' : '⚠️';

        div.innerHTML = `
      <div class="confirmation-header">
        ${riskIcon} Confirmation Required
      </div>
      <div class="confirmation-details">
        <div>Tool: <strong>${data.skill_name || '?'}</strong></div>
        <div>Risk: <strong>${data.risk_level || 'HIGH'}</strong></div>
        ${data.reason ? `<div>Reason: ${data.reason}</div>` : ''}
      </div>
      <div class="confirmation-actions">
        <button class="confirm-btn approve" onclick="app.confirmAction('${data.tool_call_id}', true)">
          ✓ Approve
        </button>
        <button class="confirm-btn deny" onclick="app.confirmAction('${data.tool_call_id}', false)">
          ✗ Deny
        </button>
      </div>
    `;

        this.messagesEl.appendChild(div);
        this._scrollToBottom();
    }

    confirmAction(toolCallId, approved) {
        this._send({
            type: 'confirm',
            session_id: this.sessionId,
            data: { tool_call_id: toolCallId, approved },
        });

        // Remove dialog and show result
        const el = document.getElementById(`confirm-${toolCallId}`);
        if (el) {
            el.innerHTML = `
        <div class="confirmation-header">
          ${approved ? '✓ Approved' : '✗ Denied'}: action
        </div>
      `;
            el.style.borderColor = approved ? 'var(--success)' : 'var(--danger)';
        }

        if (approved) {
            this._showThinking();
        }
    }

    // ─── Trust Level ──────────────────────────────────────────────────

    _setTrust(level) {
        level = level.toLowerCase();
        if (!['low', 'medium', 'high'].includes(level)) {
            this.toast(`Invalid trust level: ${level}`, 'error');
            return;
        }

        this._send({
            type: 'session.trust',
            session_id: this.sessionId,
            data: { level },
        });

        this.trustLevel = level;
        this._updateTrustUI();
        this.toast(`Trust level set to ${level.toUpperCase()}`, 'info');
    }

    _updateTrustUI() {
        document.querySelectorAll('.trust-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.level === this.trustLevel);
        });
    }

    // ─── Sidebar Actions ──────────────────────────────────────────────

    async listSkills() {
        this._hideWelcome();
        this._send({
            type: 'skills.list',
            session_id: this.sessionId,
        });
        this._addMessage('system', '🔧 Fetching skills…');
    }

    _showStatusData(data) {
        const skills = data.skills;
        if (skills) {
            // Skills list response
            const lines = skills.map(s => {
                const icon = { LOW: '🟢', MEDIUM: '🟡', HIGH: '🟠', CRITICAL: '🔴' }[s.risk_level] || '⚪';
                return `${icon} **${s.name}** — ${s.description || ''}`;
            });
            this._addMessage('assistant', `## 🔧 Available Skills (${skills.length})\n\n${lines.join('\n')}`);
            return;
        }

        // Session status
        const text = [
            `**Session:** \`${data.session_id || '?'}\``,
            `**Trust:** ${(data.trust_level || '?').toUpperCase()}`,
            `**Turns:** ${data.turns || 0} · **Tools:** ${data.tool_calls || 0}`,
            `**Tokens:** ${(data.tokens_in || 0).toLocaleString()} in / ${(data.tokens_out || 0).toLocaleString()} out`,
        ].join('\n');
        this._addMessage('assistant', `## 📊 Status\n\n${text}`);
    }

    showStatus() {
        this._hideWelcome();
        this._send({
            type: 'session.status',
            session_id: this.sessionId,
        });
    }

    clearChat() {
        // Remove all messages except welcome
        this.messagesEl.innerHTML = '';
        if (this.welcomeEl) {
            this.messagesEl.appendChild(this.welcomeEl);
            this.welcomeEl.style.display = '';
        }
    }

    toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('open');
    }

    // ─── Helpers ──────────────────────────────────────────────────────

    _scrollToBottom() {
        requestAnimationFrame(() => {
            this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
        });
    }

    _hideWelcome() {
        if (this.welcomeEl) {
            this.welcomeEl.style.display = 'none';
        }
    }

    _updateStats() {
        this.statsEl.textContent = `Turns: ${this.turnCount} · Tools: ${this.toolCount}`;
    }

    toast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        container.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'toastOut 300ms ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
}

// ─── Init ────────────────────────────────────────────────────────────────

const app = new NeuralClawApp();
