"""
gateway/session_store.py — Centralized Session Store

Owns all Session objects. Maps session_id → Session.
Thread-safe for concurrent WebSocket handlers.
"""

from __future__ import annotations

import threading
from typing import Optional

from agent.session import Session
from skills.types import TrustLevel
from observability.logger import get_logger

log = get_logger(__name__)


class SessionStore:
    """
    Thread-safe session store for the gateway.

    Sessions are created on-demand or explicitly via create().
    The store is shared across all WebSocket connections.
    """

    def __init__(self, default_trust: TrustLevel = TrustLevel.LOW):
        self._sessions: dict[str, Session] = {}
        self._lock = threading.Lock()
        self._default_trust = default_trust

    def create(
        self,
        user_id: str = "gateway",
        trust_level: Optional[TrustLevel] = None,
    ) -> Session:
        """Create a new session and return it."""
        trust = trust_level or self._default_trust
        session = Session.create(user_id=user_id, trust_level=trust)
        with self._lock:
            self._sessions[session.id] = session
        log.info("session_store.created", session_id=session.id, trust=trust.value)
        return session

    def get(self, session_id: str) -> Optional[Session]:
        """Get a session by ID, or None if not found."""
        with self._lock:
            return self._sessions.get(session_id)

    def get_or_create(
        self,
        session_id: Optional[str] = None,
        user_id: str = "gateway",
    ) -> Session:
        """Get an existing session or create a new one."""
        if session_id:
            session = self.get(session_id)
            if session:
                return session
        return self.create(user_id=user_id)

    def remove(self, session_id: str) -> bool:
        """Remove a session. Returns True if it existed."""
        with self._lock:
            return self._sessions.pop(session_id, None) is not None

    def list_sessions(self) -> list[str]:
        """Return all active session IDs."""
        with self._lock:
            return list(self._sessions.keys())

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._sessions)
