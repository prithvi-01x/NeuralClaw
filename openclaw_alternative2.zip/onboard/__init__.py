"""onboard — NeuralClaw Interactive Setup Wizard."""
from onboard.wizard import run_onboard

__all__ = ["run_onboard"]