# 🐾 NeuralClaw — Complete Project Analysis

# 🐾 NeuralClaw — Complete Technical Deep Dive

> **Project:** NeuralClaw (OpenClaw Alternative)
> 

> **Type:** Local-first Autonomous AI Agent Platform
> 

> **Python:** 3.11+
> 

> **Status:** Active / Production-ready
> 

---

## 📌 What Is NeuralClaw?

NeuralClaw is a **highly resilient, local-first autonomous AI agent platform** built in Python. It's designed to safely execute complex, multi-step tasks by combining an LLM brain, persistent memory, a secure tool execution bus, and extensible skills — all with a zero-trust safety kernel.

Think of it as a personal AI agent that runs on your machine, can use tools (terminal, filesystem, web, APIs), remembers past conversations, and executes long-horizon plans autonomously — while keeping humans in control at dangerous decision points.
re
```
NeuralClaw = LLM Brain + Memory Graph + Tool Bus + Interface Layer + MCP Client + Safety Kernel
```

---

## 🏗️ How The Project Works

### Core Execution Loop (Observe → Think → Act → Reflect)

Every user interaction follows this strict cycle:

1. **OBSERVE** — Parse user input, identify intent, extract parameters
2. **CONTEXT BUILD** — Retrieve conversation history from SQLite short-term memory + semantic search from ChromaDB long-term memory + load active plan
3. **THINK (LLM Call)** — Send full context + available tool schemas to LLM. Receives either a text response OR one/more tool calls
4. **ACT (Tool Execution)** — Route tool calls through the Safety Kernel → SkillBus → actual execution (terminal, filesystem, browser, API, MCP)
5. **REFLECT** — LLM integrates tool results, decides if done or needs more tool calls. Persists episode to memory.

### Two Operation Modes

**Interactive Mode (`/ask`)** — One turn at a time. Human in the loop every step. Max 10 LLM iterations per turn, 5 minute timeout.

**Autonomous Mode (`/run`)** — Planner decomposes goal into ordered steps → executes each step via `run_turn()` → auto-recovers on failure (max 3 recovery attempts per step, absolute cap of 100 plan steps) → commits episode to memory on completion.

### Turn Result States

Every turn returns a typed `TurnResult` with one of these statuses:

- `SUCCESS` — LLM gave a final text response
- `ITER_LIMIT` — Hit 10 iterations without finishing
- `TIMEOUT` — Turn exceeded 5 minutes
- `BLOCKED` — Safety kernel blocked a critical step
- `CONTEXT_LIMIT` — Input exceeded model's context window
- `ERROR` — Unhandled exception

---

## 🗂️ Full Directory & File Breakdown

### `agent/` — Core Agent Logic

| File | Purpose |
| --- | --- |
| `orchestrator.py` | Heart of the system. Runs the observe→think→act loop. Manages `run_turn()` and `run_autonomous()`. Never raises — always returns `TurnResult`. |
| `planner.py` | Decomposes high-level goals into ordered `PlanStep` lists. Has `create_plan()` and `create_recovery()` for failure handling. |
| `reasoner.py` | Evaluates operational risk before dispatching high-risk tool calls. Provides chain-of-thought heuristics. |
| `executor.py` | Routes `ToolCall` objects from orchestrator → SkillBus. Handles LOW/MEDIUM risk in parallel, HIGH/CRITICAL sequentially. |
| `reflector.py` | Post-turn reflection. Commits completed episodes to long-term memory. |
| `context_builder.py` | Assembles the full LLM message array: system prompt + memory context + conversation history + tool schemas. |
| `response_synthesizer.py` | Formats `AgentResponse` objects for UI display (text, error, tool progress, plan preview, cancelled). |
| `session.py` | Holds active session state: conversation buffer, active plan, tool call count, trust level, granted capabilities, cancellation flag. |
| `heartbeat.py` | Proactive check-in module. Reads `~/neuralclaw/HEARTBEAT.md` on a configurable interval (default: 30 min). |
| `workspace.py` | Agent file workspace management. |
| `utils.py` | Shared helpers: `fire_and_forget()` for async background tasks, `make_skill_error()` for typed error results. |

### `brain/` — LLM Provider Integrations

| File | Provider | Notes |
| --- | --- | --- |
| `llm_client.py` | Abstract base | Defines `BaseLLMClient` with `generate()`  • `health_check()`. Includes `ResilientLLMClient` (retry + failover wrapper) and `_call_with_retry()` with exponential backoff. |
| `openai_client.py` | OpenAI | GPT-4o, GPT-4-turbo, GPT-3.5 |
| `anthropic_client.py` | Anthropic | Claude 3.5 Sonnet, Claude 3 Opus |
| `ollama_client.py` | Ollama | Local models: qwen3:8b (default), llama3, codellama, mixtral. Auto-detects tool support per model. |
| `gemini_client.py` | Google Gemini | Gemini Pro, Gemini 1.5 |
| `openrouter_client.py` | OpenRouter | Gateway to 100+ models via single API key. Uses OpenAI-compatible API with extra attribution headers. |
| `bytez_client.py` | Bytez | `supports_tools = False` — chat-only mode. |
| `capabilities.py` | Registry | Tracks per-model capabilities (supports_tools). Updated dynamically when a model fails with a tool error. |
| `types.py` | Data types | `Message`, `LLMResponse`, `LLMConfig`, `ToolCall`, `ToolResult`, `ToolSchema`, `Role`, `Provider` |

### `memory/` — Multi-Tiered Memory System

| File | Backend | Purpose |
| --- | --- | --- |
| `short_term.py` | In-process | Conversation buffer, last 20 turns. Auto-compresses with `/compact`. |
| `long_term.py` | ChromaDB | Vector similarity search over past episodes, conversations, tool results. Collections: `conversations`, `knowledge`, `tool_results`, `plans`. |
| `episodic.py` | SQLite | Structured records of completed tasks, decisions, outcomes. Tables: `episodes`, `tool_calls`, `reflections`. |
| `task.py` | In-memory | Tracks plan execution state: step-by-step progress, results, durations, errors. |
| `embedder.py` | sentence-transformers | Thread-pooled text embedding generation using `BAAI/bge-small-en-v1.5`. |
| `memory_manager.py` | Unified API | Routes read/write across all three tiers. Exposes `build_memory_context()`, `store()`, `start_episode()`, `task_*` methods. |

### `skills/` — Extensible Tool System

| File | Purpose |
| --- | --- |
| `bus.py` | **SkillBus** — Central dispatcher. Full pipeline: Registry lookup → JSON schema validation → Safety Kernel → Execution with timeout → Result normalization. Per-call retry policy. Never raises to caller. |
| `registry.py` | Holds all registered skills. `list_schemas()`, `get_schema()`, `list_names()`. |
| `loader.py` | Auto-discovers Python and Markdown skills in `skills/plugins/`. |
| `base.py` | `SkillBase` abstract class — subclass to create Python skills. |
| `types.py` | `SkillCall`, `SkillResult`, `SkillManifest`, `RiskLevel`, `TrustLevel`, `SafetyDecision`, `ConfirmationRequest`. |
| `md_loader.py` | Parses `SKILL.md`-format markdown files as declarative skills. |
| `md_skill.py` | Executes a loaded Markdown skill (template substitution + LLM call). |

#### Built-in Skills (`skills/builtin/`)

| Skill | Function |
| --- | --- |
| `terminal.py` | Sandboxed shell command execution. Whitelist-enforced. Optional Docker container. |
| `filesystem.py` | File read/write/list within `allowed_paths`. Path traversal prevention via `Path.is_relative_to()`. |
| `web_search.py` | Web search integration. |
| `web_fetch.py` | HTTP fetch with Playwright browser automation. |

#### Plugin Skills (`skills/plugins/`) — 40+ Skills

**Cyber/Security:** `cyber_port_scan`, `cyber_dns_enum`, `cyber_whois_lookup`, `cyber_banner_grab`, `cyber_ssl_cert_check`, `cyber_cve_lookup`, `cyber_subdomain_enum`, `cyber_tech_fingerprint`, `cyber_http_probe`, `cyber_vuln_report_gen`

**Developer:** `dev_git_log`, `dev_git_diff`, `dev_git_blame`, `dev_lint_runner`, `dev_test_runner`, `dev_pr_summary`, `dev_code_search`, `dev_dependency_audit`, `dev_readme_gen`, `dev_file_summarize`

**Personal:** `personal_weather_fetch`, `personal_calendar_read`, `personal_email_summarize`, `personal_news_digest`, `personal_note_create`, `personal_task_manager`, `personal_reminder_set`

**Data:** `data_csv_parse`, `data_json_transform`, `data_sql_query`, `data_chart_gen`, `data_summarize_doc`, `data_diff_docs`

**Automation:** `automation_script_runner`, `automation_cron_create`, `automation_file_watcher`, `automation_webhook_sender`, `automation_slack_notify`, `automation_report_render`

**System:** `system_disk_usage`, `system_process_list`, `system_service_status`, `system_log_tail`, `system_backup_run`, `system_package_update`

**Meta/Orchestration:** `meta_daily_assistant`, `meta_autonomous_research`, `meta_recon_pipeline`, `meta_system_maintenance`, `meta_repo_audit`

### `safety/` — Zero-Trust Safety Kernel

| File | Purpose |
| --- | --- |
| `safety_kernel.py` | Master gatekeeper. Evaluates every SkillCall through 5 ordered checks: (1) enabled check, (2) capability check, (3) category whitelist, (4) risk scoring, (5) trust-level gate. Returns `SafetyDecision` (APPROVED / CONFIRM_NEEDED / BLOCKED). Fail-closed: unknown tools → BLOCKED. |
| `risk_scorer.py` | Scores tool calls with heuristics. Returns `RiskLevel` (LOW / MEDIUM / HIGH / CRITICAL). |
| `whitelist.py` | `check_path()` — prevents path traversal. `check_command()` — validates terminal commands against allowlist. |

### `interfaces/` — User-Facing Layers

| File | Interface |
| --- | --- |
| `cli.py` | Rich interactive terminal REPL. Commands: `/ask`, `/run`, `/model`, `/tools`, `/status`, `/trust`, `/grant`, `/compact`. |
| `telegram.py` | Async Telegram bot. Authorized user IDs, inline keyboards for confirmations. |
| `voice.py` | Voice pipeline (Phase F): Faster-Whisper STT → LLM → Piper TTS. |
| `model_selector.py` | Interactive model switcher. Calls `orchestrator.swap_llm_client()` mid-session. |

### `app/` — Qt Desktop App (Phase H)

| File | Purpose |
| --- | --- |
| `main_window.py` | Main Qt window. |
| `overlay.py` | Ambient always-on-top overlay for voice output. |
| `tray.py` | System tray icon with menu. |
| `hotword.py` | Always-on hotword/wake-word detection using OpenWakeWord. |
| `signals.py` | Qt signal definitions for inter-component communication. |
| `state.py` | Shared application state. |

### Other Modules

| Module | Purpose |
| --- | --- |
| `config/settings.py` | Pydantic Settings with full validation. `validate_all()` for cross-field checks. `validate_required_for_interface()` for API key checks per interface. |
| `config/config.yaml` | User-facing configuration: agent name, LLM provider/model, memory paths, safety levels, voice config, scheduler, MCP servers. |
| `scheduler/scheduler.py` | APScheduler wrapper for recurring/scheduled tasks. Max 3 concurrent tasks. |
| `mcp/manager.py` | MCP server manager. Supports stdio, HTTP, SSE transports. Auto-registers discovered tools into SkillRegistry. |
| `observability/logger.py` | structlog-based structured JSON logger. Session binding, trace context. |
| `observability/trace.py` | `TraceContext` for per-turn distributed tracing. |
| `onboard/wizard.py` | Interactive setup wizard (`python main.py onboard`). |
| `onboard/skill_installer.py` | Install skills by name/URL/file (`python main.py install <skill>`). |
| `kernel/kernel.py` | High-level agent kernel bootstrapper. |
| `exceptions.py` | Typed exception hierarchy: `NeuralClawError`, `PlanError`, `IterationLimitError`, `LLMError`, `MemoryError`. |
| `docker/sandbox/Dockerfile` | Isolated Docker sandbox for dangerous terminal commands. |

---

## 🔄 Architecture Diagram

```
╔════════════════════════════════════════════════════════╗
║              NEURALCLAW PLATFORM                       ║
║                                                        ║
║  INTERFACE LAYER                                       ║
║  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌─────────┐  ║
║  │ CLI REPL │ │ Telegram │ │  Voice   │ │Qt App   │  ║
║  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬────┘  ║
║       └────────────┴────────────┴─────────────┘       ║
║                         │                             ║
║              ORCHESTRATOR (observe→think→act)          ║
║  ┌─────────┐ ┌──────────┐ ┌────────────────────────┐  ║
║  │ Planner │ │ Reasoner │ │ Response Synthesizer   │  ║
║  └─────────┘ └──────────┘ └────────────────────────┘  ║
║       │              │               │                ║
║  ┌────▼──────┐ ┌─────▼────┐ ┌───────▼──────┐         ║
║  │ LLM BRAIN │ │  MEMORY  │ │  SKILL BUS   │         ║
║  │           │ │          │ │              │         ║
║  │ OpenAI    │ │Short-term│ │ Terminal     │         ║
║  │ Anthropic │ │(SQLite)  │ │ Filesystem   │         ║
║  │ Ollama    │ │Long-term │ │ Web/Browser  │         ║
║  │ Gemini    │ │(ChromaDB)│ │ 40+ Plugins  │         ║
║  │ OpenRouter│ │Episodic  │ │ MCP Tools    │         ║
║  │ Bytez     │ │(SQLite)  │ │              │         ║
║  └───────────┘ └──────────┘ └──────────────┘         ║
║                                    │                  ║
║  ┌─────────────────────────────────▼────────────────┐ ║
║  │              SAFETY KERNEL                       │ ║
║  │  Enabled → Capability → Whitelist → Risk → Trust │ ║
║  └──────────────────────────────────────────────────┘ ║
╚════════════════════════════════════════════════════════╝
```

---

## 🤖 AI Models: Free & Paid — Full Provider Guide

### 🟢 Free / Local Models (via Ollama)

Best for: privacy, offline use, no API costs

Install: `ollama pull <model>`

| Model | Size | Tool Support | Best For |
| --- | --- | --- | --- |
| `qwen3:8b` | 8B (default in config) | ✅ | General assistant, good balance |
| `qwen3:14b` | 14B | ✅ | Better reasoning, needs more RAM |
| `qwen3:32b` | 32B | ✅ | Near-GPT4 quality locally |
| `llama3.1:8b` | 8B | ✅ | Fast, general purpose |
| `llama3.1:70b` | 70B | ✅ | High quality, needs 64GB RAM |
| `codellama:13b` | 13B | ✅ | Code tasks |
| `deepseek-r1:8b` | 8B | ⚠️ | Reasoning/math |
| `mistral:7b` | 7B | ✅ | Fast, efficient |
| `phi3:mini` | 3.8B | ⚠️ | Ultra fast on low-end hardware |
| `gemma2:9b` | 9B | ✅ | Google's open model |
| `nomic-embed-text` | — | N/A | Embeddings (alternative to BAAI) |

### 🔵 Paid — OpenAI

Set in config: `default_provider: openai`, `default_model: gpt-4o`

| Model | Tool Support | Strengths | Cost |
| --- | --- | --- | --- |
| `gpt-4o` | ✅ | Best overall, fast | ~$5/1M input |
| `gpt-4o-mini` | ✅ | Budget pick, fast | ~$0.15/1M input |
| `gpt-4-turbo` | ✅ | 128K context | ~$10/1M input |
| `o1-mini` | ❌ | Reasoning tasks | ~$3/1M input |
| `o3-mini` | ⚠️ | Best reasoning | ~$1.1/1M input |

### 🟠 Paid — Anthropic

Set in config: `default_provider: anthropic`, `default_model: claude-sonnet-4-5`

| Model | Tool Support | Strengths | Cost |
| --- | --- | --- | --- |
| `claude-opus-4-5` | ✅ | Most capable, complex tasks | ~$15/1M input |
| `claude-sonnet-4-5` | ✅ | Best balance speed/quality | ~$3/1M input |
| `claude-haiku-4-5` | ✅ | Fastest, cheapest | ~$0.25/1M input |

### 🔴 Paid — Google Gemini

Set in config: `default_provider: gemini`

| Model | Tool Support | Strengths | Cost |
| --- | --- | --- | --- |
| `gemini-1.5-pro` | ✅ | 2M context window | ~$3.5/1M input |
| `gemini-1.5-flash` | ✅ | Fast + cheap | ~$0.075/1M input |
| `gemini-2.0-flash` | ✅ | Latest, fast | ~$0.10/1M input |

### 🟣 OpenRouter — 100+ Models via Single API Key

Set in config: `default_provider: openrouter`

OpenRouter lets you route to any major model with one key. Best for experimentation.

| Model String | Provider | Notes |
| --- | --- | --- |
| `anthropic/claude-3.5-sonnet` | Anthropic | Via OpenRouter |
| `openai/gpt-4o` | OpenAI | Via OpenRouter |
| `meta-llama/llama-3.1-70b-instruct` | Meta/Together | Free tier available |
| `google/gemini-pro-1.5` | Google | Via OpenRouter |
| `mistralai/mixtral-8x22b-instruct` | Mistral | Strong OSS model |
| `nousresearch/hermes-3-llama-3.1-405b` | Nous | Tool calling focused |
| `x-ai/grok-beta` | xAI | Large context |

Free models on OpenRouter (rate limited): `meta-llama/llama-3.2-3b-instruct:free`, `google/gemma-2-9b-it:free`

### 🟡 Bytez

Set in config: `default_provider: bytez`

⚠️ **Note:** `supports_tools = False` — runs in chat-only mode. No tool calling.

Good for: simple Q&A, no tool use needed.

### 🏆 Recommended Model Per Use Case

| Use Case | Best Free | Best Paid |
| --- | --- | --- |
| General coding agent | `qwen3:14b` | `claude-sonnet-4-5` |
| Cyber security tasks | `qwen3:32b` | `gpt-4o` |
| Long autonomous runs | `llama3.1:70b` | `claude-opus-4-5` |
| Fast interactive chat | `phi3:mini` / `mistral:7b` | `gemini-2.0-flash` |
| Data analysis | `qwen3:8b` | `gpt-4o` |
| Budget API | OpenRouter free tier | `gpt-4o-mini` |

---

## 🐛 Known Bugs & Issues

### 1. `_execute_tool_calls` Result Ordering Bug Risk

In `orchestrator.py`, results are collected into a pre-allocated `[None] * len(brain_tool_calls)` list. If any parallel task raises AND the exception handler fails silently, an `unfilled` slot exists and raises a `RuntimeError`. The guard exists but the error message exposes internal structure to logs.

**Fix:** Wrap in typed `ToolExecutionError` with cleaner user message.

### 2. ResilientLLMClient `supports_tools` Propagation

When `_register_no_tools()` is called after a tool error, it sets `supports_tools = False` on both the wrapper and inner client — but only after checking `isinstance(client, ResilientLLMClient)`. If the wrapper is nested more than one level deep, the inner client may not be updated.

**Fix:** Add a recursive unwrap helper.

### 3. Autonomous Loop Timeout Implementation

The `run_autonomous()` generator wraps individual `anext()` calls with `asyncio.wait_for()` per item. If a single step takes longer than the remaining time, it raises `TimeoutError` correctly — but the finally block that calls `task_fail()` and `clear_plan()` may not run because the generator's `finally` block is inside a `try/except asyncio.TimeoutError`. This is partially mitigated but edge cases remain.

### 4. Memory Embedder Thread Pool Not Shut Down

`embedder.py` uses a `ThreadPoolExecutor` for embedding generation but there's no explicit shutdown hook on application exit. On force-quit, orphaned threads may block Python's garbage collection.

**Fix:** Add `atexit.register(executor.shutdown)` in embedder init.

### 5. Telegram Confirmation Race Condition

When multiple tool calls require confirmation in a single turn, the async confirmation handler uses a session-scoped asyncio Event. Rapid approvals from Telegram could cause a second confirmation to resolve the first event prematurely.

**Fix:** Use per-confirmation-request events keyed by `tool_call_id`.

### 6. Model Swap Doesn't Invalidate ChromaDB Embeddings

Swapping to a model with a different embedding space (e.g., switching from OpenAI embeddings to local BAAI) doesn't re-embed historical memory. Semantic search results will be incorrect.

**Fix:** Add an embedding model version tag to ChromaDB metadata and warn on mismatch.

### 7. `compact_session()` Has No Idempotency Guard

Calling `/compact` twice in rapid succession can result in two concurrent LLM calls both summarizing the same context, then both trying to write back — with the second overwriting the first.

**Fix:** Add a session-scoped `_compaction_in_progress: bool` flag.

### 8. `config.yaml` `whitelist_extra: ["*"]` Bypass

The config schema accepts `["*"]` as a value for `tools.terminal.whitelist_extra` which is documented as disabled the safety whitelist entirely — but there's no validator that prevents a user from setting this accidentally.

**Fix:** Add a Pydantic validator that raises `ConfigError` if `"*"` is present.

---

## ⚡ What I Did To Increase Speed

### 1. Tool Schema Caching

```python
# orchestrator.py — line ~250
if self._cached_tool_schemas is None:
    self._cached_tool_schemas = [...build from registry...]
all_tool_schemas = self._cached_tool_schemas  # reused every iteration
```

The registry is static after startup. Without caching, every LLM call rebuilt the full tool schema list from scratch. Now it's built once and reused.

### 2. Markdown Skill Instructions Caching

```python
if self._cached_md_instructions is None:
    self._cached_md_instructions = _MdSkillLoader().get_instructions_block(self._registry)
```

Markdown skill system prompt injection was recomputed per call. Now cached per instance.

### 3. Parallel Tool Execution (LOW/MEDIUM risk)

```python
# executor.py
if low:
    tasks = [self._executor.dispatch(btc, ...) for _, btc in low]
    parallel = await asyncio.gather(*tasks, return_exceptions=True)
```

LOW and MEDIUM risk tool calls are gathered concurrently. Only HIGH/CRITICAL calls are sequential (required for safety confirmation). This can 2-3x throughput on multi-tool turns.

### 4. Fire-and-Forget Memory Persistence

```python
# orchestrator.py
_fire_and_forget(
    self._persist_turn(session, user_message, turn_result.response.text),
    label="persist_turn",
)
```

Memory writes to ChromaDB and SQLite happen in the background — they don't block the response to the user. Same for episode persistence after autonomous runs.

### 5. Thread-Pooled Embedding Generation

```python
# memory/embedder.py
# ThreadPoolExecutor wraps sentence-transformers (CPU-bound)
```

Embedding generation is CPU-bound and would block the asyncio event loop. Offloaded to a thread pool, so memory search doesn't stall LLM calls.

### 6. Session Context Compression (`/compact`)

When the conversation grows past 15 turns (configurable), the CLI suggests `/compact`. This uses the LLM to produce a 5-sentence summary and replaces all but the 4 most recent turns — keeping the context window small and LLM calls cheaper/faster.

### 7. Capability Registry for Tool Support Detection

```python
# brain/capabilities.py
_registry: dict[str, ModelCapabilities] = {}
def register_capabilities(provider, model_id, supports_tools):
    ...
```

Instead of probing the model on every call to check if it supports tools, results are cached in a global registry keyed by `(provider, model_id)`. Failed tool calls auto-update the registry to disable tools for that model.

### 8. Retry with Exponential Backoff (not naive sleep)

```python
# brain/llm_client.py
delay = min(base_delay * (2 ** attempt) + random.uniform(0, 0.5), max_delay)
```

Transient network errors and rate limits are retried with jitter to prevent thundering-herd against provider APIs.

### 9. Per-Skill Retry Overrides

```yaml
# config.yaml
skills:
  retry:
    overrides:
      terminal_exec:
        max_attempts: 1   # never retry shell commands (not idempotent)
      web_fetch:
        max_attempts: 3
```

Terminal commands are never retried (side effects). Web fetches get 3 retries. This prevents wasted tokens and time on non-retryable failures.

### 10. Async-First Architecture

Entire stack is built on `asyncio` — LLM calls, tool execution, memory reads/writes, Telegram polling, scheduler. No blocking I/O on the main event loop.

---

## 🚀 Things We Can Add (Feature Roadmap)

### High Priority

**1. Web Dashboard (REST API)**

Add FastAPI endpoints (already a dependency in `requirements.txt`) for a browser-based control panel. View session history, memory contents, tool logs, active plans, and issue commands.

**2. Docker Sandbox by Default**

The `docker_sandbox: false` config flag exists but isn't enforced as default. Making Docker sandboxing the default for terminal execution would dramatically reduce risk for new users.

**3. Multi-User Support**

Session management currently assumes one user. Add user authentication layer to support multiple Telegram users with isolated sessions, separate memory stores, and per-user trust levels.

**4. Streaming LLM Responses**

Current implementation awaits the full LLM response before displaying. Add streaming support (all providers support it) so users see token-by-token output — much better UX for long responses.

**5. Vision/Multimodal Input**

Add image input support to the Telegram and CLI interfaces. Send screenshots to GPT-4o or Claude for visual reasoning tasks.

### Medium Priority

**6. Skill Marketplace**

Expand `onboard/skill_installer.py` into a full registry. Users can browse, install, rate, and share skills from a central GitHub-based registry.

**7. Memory Search UI**

Add `/memory search <query>` CLI command that displays top-k semantic matches from ChromaDB with their metadata — so users can inspect what the agent remembers.

**8. Plan Visualization**

In autonomous mode, display the full plan as an ASCII tree or Rich table before execution starts, with real-time step highlighting as execution progresses.

**9. Agent-to-Agent Communication**

Add a skill that allows NeuralClaw to spawn and communicate with sub-agents (separate processes or API calls to other NeuralClaw instances) for parallel task execution.

**10. LangSmith / Langfuse Integration**

Plug observability into LangSmith or Langfuse for full trace visualization, cost tracking, and prompt debugging — using the existing `TraceContext` infrastructure.

**11. Prompt Templates Library**

Add a `prompts/` directory with pre-built system prompt templates for different agent personas: security researcher, developer assistant, data analyst, personal assistant.

**12. RBAC for Skills**

Role-based access control on skills — e.g., `cyber_port_scan` only callable by users with `security` role. Extends the existing `TrustLevel` system.

**13. Semantic Deduplication in Memory**

Before writing to ChromaDB, check cosine similarity against recent writes. If similarity > 0.95, skip writing to prevent memory bloat from repeated identical interactions.

**14. Auto-Summarization of Tool Results**

Long tool outputs (e.g., 10,000-char terminal output) are currently truncated. Instead, auto-summarize with a fast/cheap LLM call before injecting into context.

**15. Export / Import Sessions**

Allow exporting a full session (conversation + memory + plans) to JSON for backup, sharing, or resuming on a different machine.

### Lower Priority

**16. Voice: CUDA Acceleration**

`whisper_device: cpu` in config. Add GPU detection and auto-switch to CUDA for 5-10x faster STT on machines with NVIDIA GPUs.

**17. Browser Extension Integration**

Allow the agent to receive tasks from a browser extension ("Summarize this page", "Research this topic") using a local WebSocket server.

**18. Webhook Trigger Interface**

Beyond Telegram, add an HTTP webhook interface so external systems (GitHub, CI/CD, monitoring tools) can trigger agent tasks automatically.

**19. Cost Tracking Dashboard**

Track token usage per session/day/model and calculate estimated costs. Alert when monthly spend approaches a configured budget.

**20. Automated Testing of Skills**

Add a `skill_test_runner.py` that executes each skill with mock inputs and validates outputs match expected schema — catching broken plugins before they fail in production.

---

## 📦 Dependencies Overview

| Package | Purpose |
| --- | --- |
| `pydantic` / `pydantic-settings` | Config validation, type safety |
| `rich` | Beautiful CLI terminal UI |
| `httpx` | Async HTTP client |
| `structlog` | Structured JSON logging |
| `openai` | OpenAI + OpenRouter + any OpenAI-compatible |
| `anthropic` | Anthropic Claude API |
| `ollama` | Local model management |
| `bytez` | Bytez provider |
| `chromadb` | Vector database for long-term memory |
| `sentence-transformers` | Local text embeddings (BAAI/bge-small-en-v1.5) |
| `aiosqlite` | Async SQLite for short-term/episodic memory |
| `playwright` | Browser automation for web tools |
| `python-telegram-bot` | Telegram interface |
| `psutil` | System process management |
| `fastapi`  • `uvicorn` | Future REST API (already included) |
| `prometheus-client` | Metrics collection |
| `pytest`  • `pytest-asyncio` | Testing |

---

## 🛡️ Security Architecture Summary

NeuralClaw implements 6 security layers:

1. **API Key Security** — Keys in `.env` only, never logged or serialized
2. **Input Validation** — JSON Schema validation on all tool parameters before execution
3. **Safety Kernel** — 5-step evaluation: enabled → capability → whitelist → risk score → trust gate
4. **Execution Sandbox** — Optional Docker container for terminal; Playwright isolation for browser
5. **Audit Logging** — Every tool call, LLM call, and safety decision is logged with full metadata
6. **MCP Security** — MCP servers must be explicitly listed in config; their calls pass through Safety Kernel

Risk levels and their behavior:

| Risk | Level | Default Behavior |
| --- | --- | --- |
| Browser navigate, file read, web search | LOW | Auto-approved |
| File write, API calls | MEDIUM | Auto-approved |
| Terminal exec, file delete | HIGH | User confirmation required |
| Destructive system ops | CRITICAL | Always blocked at `low` trust |

---

## 🧪 Test Coverage

Tests live in `tests/` with three layers:

- **Unit** (`tests/unit/`) — `test_brain.py`, `test_memory.py`, `test_skills.py`, `test_safety.py`, `test_orchestrator.py`, `test_cli.py`, `test_config.py`, `test_voice.py`, and phase-specific tests
- **Integration** (`tests/integration/test_agent_integration.py`) — End-to-end agent + memory + skills
- **E2E** (`tests/e2e/test_agent_e2e.py`) — Full stack including interfaces

Run: `venv/bin/python -m pytest tests/`

---

## 🚀 Quick Start

```bash
# 1. Clone and setup
git clone https://github.com/gabimaruu/neuralclaw.git
cd neuralclaw
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 2. Configure
cp .env.example .env
# Edit .env with your API keys

# 3. Run onboarding wizard
python main.py onboard

# 4. Start CLI
python main.py

# 5. Or start Telegram bot
python main.py --interface telegram

# 6. Or voice interface
python main.py --interface voice

# 7. Or Qt desktop app (requires PyQt6)
python main.py --interface voice-app
```

---

*Analysis generated from full source code review — all 150+ files across 15 modules.*